from libcity.model.traffic_accident_prediction.GSNet import GSNet

__all__ = [
    "GSNet",
]
